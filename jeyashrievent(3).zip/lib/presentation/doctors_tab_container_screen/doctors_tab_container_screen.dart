import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/doctors_page/doctors_page.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/forget_password_page/forget_password_page.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_trailing_image.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_bottom_bar.dart';

class DoctorsTabContainerScreen extends StatefulWidget {
  const DoctorsTabContainerScreen({Key? key})
      : super(
          key: key,
        );

  @override
  DoctorsTabContainerScreenState createState() =>
      DoctorsTabContainerScreenState();
}

class DoctorsTabContainerScreenState extends State<DoctorsTabContainerScreen>
    with TickerProviderStateMixin {
  late TabController tabviewController;

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    tabviewController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 19.v),
              _buildTabview(context),
              SizedBox(
                height: 569.v,
                child: TabBarView(
                  controller: tabviewController,
                  children: [
                    DoctorsPage(),
                    DoctorsPage(),
                    DoctorsPage(),
                    DoctorsPage(),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      title: AppbarTitle(
        text: "Doctors",
        margin: EdgeInsets.only(left: 20.h),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgRewindPrimarycontainer,
          margin: EdgeInsets.fromLTRB(20.h, 16.v, 14.h, 2.v),
        ),
        AppbarTrailingImage(
          imagePath: ImageConstant.imgShare,
          margin: EdgeInsets.only(
            left: 24.h,
            top: 14.v,
            right: 34.h,
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildTabview(BuildContext context) {
    return Container(
      height: 36.v,
      width: double.maxFinite,
      child: TabBar(
        controller: tabviewController,
        isScrollable: true,
        labelColor: theme.colorScheme.onPrimaryContainer.withOpacity(1),
        labelStyle: TextStyle(
          fontSize: 14.fSize,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelColor: appTheme.indigoA100,
        unselectedLabelStyle: TextStyle(
          fontSize: 14.fSize,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
        ),
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(
            18.h,
          ),
          gradient: LinearGradient(
            begin: Alignment(1, 1),
            end: Alignment(-0.24, -0.31),
            colors: [
              appTheme.indigoA100,
              theme.colorScheme.primary,
            ],
          ),
        ),
        tabs: [
          Tab(
            child: Text(
              "All",
            ),
          ),
          Tab(
            child: Text(
              "General",
            ),
          ),
          Tab(
            child: Text(
              "Dentist",
            ),
          ),
          Tab(
            child: Text(
              "Partial",
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.forgetPasswordPage;
      case BottomBarEnum.Appointment:
        return "/";
      case BottomBarEnum.Doctors:
        return "/";
      case BottomBarEnum.Article:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.forgetPasswordPage:
        return ForgetPasswordPage();
      default:
        return DefaultWidget();
    }
  }
}
