import '../doctors_page/widgets/doccardlist_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';

// ignore_for_file: must_be_immutable
class DoctorsPage extends StatefulWidget {
  const DoctorsPage({Key? key})
      : super(
          key: key,
        );

  @override
  DoctorsPageState createState() => DoctorsPageState();
}

class DoctorsPageState extends State<DoctorsPage>
    with AutomaticKeepAliveClientMixin<DoctorsPage> {
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.outlineBlack,
          child: Column(
            children: [
              SizedBox(height: 20.v),
              _buildDocCardList(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildDocCardList(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.h),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            height: 12.v,
          );
        },
        itemCount: 5,
        itemBuilder: (context, index) {
          return DoccardlistItemWidget();
        },
      ),
    );
  }
}
