import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_rating_bar.dart';

// ignore: must_be_immutable
class DoccardlistItemWidget extends StatelessWidget {
  const DoccardlistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.h),
      decoration: AppDecoration.fillOnPrimaryContainer.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder20,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage6,
            height: 74.adaptSize,
            width: 74.adaptSize,
            radius: BorderRadius.circular(
              37.h,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 12.h,
              top: 5.v,
              bottom: 7.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "DR Williem Smith",
                  style: CustomTextStyles.titleSmallOnErrorContainer,
                ),
                SizedBox(height: 2.v),
                Text(
                  "Dentist | Royal Hospital ",
                  style: CustomTextStyles.bodySmallGray600,
                ),
                SizedBox(height: 1.v),
                Row(
                  children: [
                    CustomRatingBar(
                      ignoreGestures: true,
                      initialRating: 2,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 4.h),
                      child: Text(
                        "4.8",
                        style: CustomTextStyles.bodySmallGray90001,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgComponent1,
            height: 32.adaptSize,
            width: 32.adaptSize,
            margin: EdgeInsets.only(
              top: 7.v,
              bottom: 35.v,
            ),
          ),
        ],
      ),
    );
  }
}
