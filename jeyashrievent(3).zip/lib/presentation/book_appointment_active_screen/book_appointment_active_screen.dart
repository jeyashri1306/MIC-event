import '../book_appointment_active_screen/widgets/twentyfive_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:outline_gradient_button/outline_gradient_button.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_leading_image.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_subtitle.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_elevated_button.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_outlined_button.dart';

// ignore_for_file: must_be_immutable
class BookAppointmentActiveScreen extends StatelessWidget {
  BookAppointmentActiveScreen({Key? key}) : super(key: key);

  DateTime? rangeStart;

  DateTime? rangeEnd;

  DateTime? selectedDay;

  DateTime focusedDay = DateTime.now();

  RangeSelectionMode rangeSelectionMode = RangeSelectionMode.toggledOn;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 16.v),
                    child: Column(children: [
                      _buildDocCard(context),
                      SizedBox(height: 19.v),
                      _buildFrame(context),
                      SizedBox(height: 19.v),
                      _buildSixtySeven(context)
                    ])))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 40.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 16.h, top: 14.v, bottom: 14.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarSubtitle(text: "Book Appointment "),
        styleType: Style.bgFill_1);
  }

  /// Section Widget
  Widget _buildDocCard(BuildContext context) {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 20.h),
        padding: EdgeInsets.all(20.h),
        decoration: AppDecoration.gradientIndigoAToPrimary
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder20),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
              height: 74.adaptSize,
              width: 74.adaptSize,
              decoration: AppDecoration.fillGray
                  .copyWith(borderRadius: BorderRadiusStyle.circleBorder37),
              child: CustomImageView(
                  imagePath: ImageConstant.imgImage81,
                  height: 74.v,
                  width: 67.h,
                  radius: BorderRadius.circular(37.h),
                  alignment: Alignment.centerRight)),
          Padding(
              padding: EdgeInsets.fromLTRB(12.h, 5.v, 22.h, 5.v),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Dr. Jennie Thorn",
                        style: CustomTextStyles.titleSmallOnErrorContainer),
                    SizedBox(height: 1.v),
                    Text("Dentist ",
                        style: CustomTextStyles.bodySmallGray90001),
                    SizedBox(height: 3.v),
                    Row(children: [
                      CustomImageView(
                          imagePath: ImageConstant.imgIconLocation,
                          height: 18.adaptSize,
                          width: 18.adaptSize),
                      Padding(
                          padding: EdgeInsets.only(left: 2.h),
                          child: Text("Royal Hospital, Phonm Penh",
                              style: CustomTextStyles.bodySmallGray90001))
                    ])
                  ]))
        ]));
  }

  /// Section Widget
  Widget _buildFrame(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 19.h),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
              padding: EdgeInsets.only(left: 1.h),
              child: Text("Select Date", style: theme.textTheme.titleMedium)),
          SizedBox(height: 12.v),
          SizedBox(
              height: 280.v,
              width: 336.h,
              child: TableCalendar(
                  locale: 'en_US',
                  firstDay: DateTime(DateTime.now().year - 5),
                  lastDay: DateTime(DateTime.now().year + 5),
                  calendarFormat: CalendarFormat.month,
                  rangeSelectionMode: rangeSelectionMode,
                  startingDayOfWeek: StartingDayOfWeek.monday,
                  headerStyle: HeaderStyle(
                      formatButtonVisible: false, titleCentered: true),
                  calendarStyle: CalendarStyle(
                      outsideDaysVisible: false,
                      isTodayHighlighted: true,
                      todayTextStyle: TextStyle(
                          color: theme.colorScheme.primaryContainer,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600),
                      todayDecoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12.h))),
                  daysOfWeekStyle: DaysOfWeekStyle(
                      weekdayStyle: TextStyle(
                          color: appTheme.gray90001,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600)),
                  headerVisible: false,
                  rowHeight: 24.adaptSize,
                  focusedDay: focusedDay,
                  rangeStartDay: rangeStart,
                  rangeEndDay: rangeEnd,
                  onDaySelected: (selectedDay, focusedDay) {},
                  onRangeSelected: (start, end, focusedDay) {},
                  onPageChanged: (focusedDay) {}))
        ]));
  }

  /// Section Widget
  Widget _buildThirtyFour(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text("Select Hour", style: theme.textTheme.titleMedium),
      SizedBox(height: 12.v),
      Wrap(
          runSpacing: 10.v,
          spacing: 10.h,
          children: List<Widget>.generate(6, (index) => TwentyfiveItemWidget()))
    ]);
  }

  /// Section Widget
  Widget _buildSixtySeven(BuildContext context) {
    return SizedBox(
        height: 240.v,
        width: double.maxFinite,
        child: Stack(alignment: Alignment.bottomCenter, children: [
          Align(
              alignment: Alignment.center,
              child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.h),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    _buildThirtyFour(context),
                    SizedBox(height: 12.v),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Expanded(
                          child: Padding(
                              padding: EdgeInsets.only(right: 5.h),
                              child: OutlineGradientButton(
                                  padding: EdgeInsets.only(
                                      left: 1.h,
                                      top: 1.v,
                                      right: 1.h,
                                      bottom: 1.v),
                                  strokeWidth: 1.h,
                                  gradient: LinearGradient(
                                      begin: Alignment(1, 1),
                                      end: Alignment(-0.24, -0.31),
                                      colors: [
                                        appTheme.indigoA100,
                                        theme.colorScheme.primary
                                      ]),
                                  corners: Corners(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                      bottomLeft: Radius.circular(20),
                                      bottomRight: Radius.circular(20)),
                                  child:
                                      CustomOutlinedButton(text: "14:00 PM")))),
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 5.h),
                          child: OutlineGradientButton(
                              padding: EdgeInsets.only(
                                  left: 1.h, top: 1.v, right: 1.h, bottom: 1.v),
                              strokeWidth: 1.h,
                              gradient: LinearGradient(
                                  begin: Alignment(1, 1),
                                  end: Alignment(-0.24, -0.31),
                                  colors: [
                                    appTheme.indigoA100,
                                    theme.colorScheme.primary
                                  ]),
                              corners: Corners(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20),
                                  bottomLeft: Radius.circular(20),
                                  bottomRight: Radius.circular(20)),
                              child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 21.h, vertical: 9.v),
                                  decoration: AppDecoration.outline.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder20),
                                  child: Text("14:30 PM",
                                      style: theme.textTheme.titleSmall)))),
                      Expanded(
                          child: Padding(
                              padding: EdgeInsets.only(left: 5.h),
                              child: OutlineGradientButton(
                                  padding: EdgeInsets.only(
                                      left: 1.h,
                                      top: 1.v,
                                      right: 1.h,
                                      bottom: 1.v),
                                  strokeWidth: 1.h,
                                  gradient: LinearGradient(
                                      begin: Alignment(1, 1),
                                      end: Alignment(-0.24, -0.31),
                                      colors: [
                                        appTheme.indigoA100,
                                        theme.colorScheme.primary
                                      ]),
                                  corners: Corners(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                      bottomLeft: Radius.circular(20),
                                      bottomRight: Radius.circular(20)),
                                  child:
                                      CustomOutlinedButton(text: "15:00 PM"))))
                    ]),
                    SizedBox(height: 12.v),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                              width: 105.h,
                              decoration: AppDecoration.outline.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: OutlineGradientButton(
                                  padding: EdgeInsets.only(
                                      left: 1.h,
                                      top: 1.v,
                                      right: 1.h,
                                      bottom: 1.v),
                                  strokeWidth: 1.h,
                                  gradient: LinearGradient(
                                      begin: Alignment(1, 1),
                                      end: Alignment(-0.24, -0.31),
                                      colors: [
                                        appTheme.indigoA100,
                                        theme.colorScheme.primary
                                      ]),
                                  corners: Corners(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                      bottomLeft: Radius.circular(20),
                                      bottomRight: Radius.circular(20)),
                                  child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 22.h, vertical: 10.v),
                                      child: Text("15:30 PM",
                                          style: theme.textTheme.titleSmall)))),
                          Container(
                              width: 105.h,
                              decoration: AppDecoration.outline.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: OutlineGradientButton(
                                  padding: EdgeInsets.only(
                                      left: 1.h,
                                      top: 1.v,
                                      right: 1.h,
                                      bottom: 1.v),
                                  strokeWidth: 1.h,
                                  gradient: LinearGradient(
                                      begin: Alignment(1, 1),
                                      end: Alignment(-0.24, -0.31),
                                      colors: [
                                        appTheme.indigoA100,
                                        theme.colorScheme.primary
                                      ]),
                                  corners: Corners(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                      bottomLeft: Radius.circular(20),
                                      bottomRight: Radius.circular(20)),
                                  child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 21.h, vertical: 10.v),
                                      child: Text("16:00 PM",
                                          style: theme.textTheme.titleSmall)))),
                          Container(
                              width: 105.h,
                              decoration: AppDecoration.outline.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: OutlineGradientButton(
                                  padding: EdgeInsets.only(
                                      left: 1.h,
                                      top: 1.v,
                                      right: 1.h,
                                      bottom: 1.v),
                                  strokeWidth: 1.h,
                                  gradient: LinearGradient(
                                      begin: Alignment(1, 1),
                                      end: Alignment(-0.24, -0.31),
                                      colors: [
                                        appTheme.indigoA100,
                                        theme.colorScheme.primary
                                      ]),
                                  corners: Corners(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                      bottomLeft: Radius.circular(20),
                                      bottomRight: Radius.circular(20)),
                                  child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 22.h, vertical: 10.v),
                                      child: Text("16:30 PM",
                                          style: theme.textTheme.titleSmall))))
                        ])
                  ]))),
          Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                  margin: EdgeInsets.only(bottom: 10.v),
                  padding:
                      EdgeInsets.symmetric(horizontal: 16.h, vertical: 12.v),
                  decoration: AppDecoration.outlineBlack900,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    SizedBox(height: 22.v),
                    CustomElevatedButton(
                        text: "NEXT",
                        buttonStyle: CustomButtonStyles.none,
                        decoration: CustomButtonStyles
                            .gradientIndigoAToPrimaryDecoration)
                  ])))
        ]));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }
}
