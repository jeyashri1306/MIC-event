import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_icon_button.dart';

// ignore: must_be_immutable
class GeneralcomponentItemWidget extends StatelessWidget {
  const GeneralcomponentItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CustomIconButton(
          height: 52.adaptSize,
          width: 52.adaptSize,
          padding: EdgeInsets.all(10.h),
          child: CustomImageView(
            imagePath: ImageConstant.imgGeneral,
          ),
        ),
        SizedBox(height: 9.v),
        Text(
          "General",
          style: theme.textTheme.bodyMedium,
        ),
      ],
    );
  }
}
