import '../forget_password_page/widgets/generalcomponent_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:outline_gradient_button/outline_gradient_button.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_leading_image.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_subtitle_one.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_subtitle_three.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_trailing_image.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_elevated_button.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_search_view.dart';

// ignore_for_file: must_be_immutable
class ForgetPasswordPage extends StatelessWidget {
  ForgetPasswordPage({Key? key})
      : super(
          key: key,
        );

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 20.v),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: CustomSearchView(
                  controller: searchController,
                  hintText: "Search ",
                ),
              ),
              SizedBox(height: 20.v),
              _buildWelcomeBackGroup(context),
              SizedBox(height: 20.v),
              _buildDoctorSpecialityGrid(context),
              SizedBox(height: 31.v),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: _buildFrame(
                  context,
                  doctorSpeciality: "Top Doctors",
                  seeAllPrice: "SEE ALL",
                ),
              ),
              SizedBox(height: 14.v),
              _buildListTabStack(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 57.v,
      leadingWidth: 62.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgPlay,
        margin: EdgeInsets.only(
          left: 20.h,
          top: 4.v,
          bottom: 9.v,
        ),
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 8.h),
        child: Column(
          children: [
            AppbarSubtitleThree(
              text: "Welcome Back,",
              margin: EdgeInsets.only(right: 4.h),
            ),
            SizedBox(height: 6.v),
            AppbarSubtitleOne(
              text: "Stefani Wong",
            ),
          ],
        ),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgFrame1171275198,
          margin: EdgeInsets.only(
            left: 20.h,
            top: 10.v,
            right: 18.h,
          ),
        ),
        AppbarTrailingImage(
          imagePath: ImageConstant.imgFramePrimarycontainer,
          margin: EdgeInsets.fromLTRB(24.h, 12.v, 38.h, 1.v),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildWelcomeBackGroup(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20.h),
      child: Column(
        children: [
          _buildFrame(
            context,
            doctorSpeciality: "Upcoming Appointment ",
            seeAllPrice: "SEE ALL",
          ),
          SizedBox(height: 15.v),
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 20.h,
              vertical: 19.v,
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadiusStyle.roundedBorder20,
              image: DecorationImage(
                image: fs.Svg(
                  ImageConstant.imgBanner,
                ),
                fit: BoxFit.cover,
              ),
            ),
            foregroundDecoration:
                AppDecoration.gradientIndigoAToPrimary.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder20,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      height: 52.adaptSize,
                      width: 52.adaptSize,
                      decoration: AppDecoration.fillGray.copyWith(
                        borderRadius: BorderRadiusStyle.circleBorder26,
                      ),
                      child: CustomImageView(
                        imagePath: ImageConstant.imgImage8,
                        height: 52.v,
                        width: 47.h,
                        radius: BorderRadius.circular(
                          26.h,
                        ),
                        alignment: Alignment.centerRight,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 20.h,
                        top: 5.v,
                        bottom: 5.v,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "DR Williem Smith",
                            style:
                                CustomTextStyles.titleSmallOnPrimaryContainer,
                          ),
                          SizedBox(height: 2.v),
                          Text(
                            "Dentist | Royal Hospital ",
                            style: CustomTextStyles.bodySmallOnPrimaryContainer,
                          ),
                        ],
                      ),
                    ),
                    Spacer(),
                    CustomImageView(
                      imagePath: ImageConstant.imgNotification,
                      height: 20.adaptSize,
                      width: 20.adaptSize,
                      margin: EdgeInsets.only(bottom: 32.v),
                    ),
                  ],
                ),
                SizedBox(height: 12.v),
                Row(
                  children: [
                    CustomElevatedButton(
                      height: 38.v,
                      width: 104.h,
                      text: "Sep 10, 2023",
                      leftIcon: Container(
                        margin: EdgeInsets.only(right: 5.h),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgCalendar,
                          height: 18.adaptSize,
                          width: 18.adaptSize,
                        ),
                      ),
                      buttonStyle: CustomButtonStyles.fillBlack,
                      buttonTextStyle:
                          CustomTextStyles.labelMediumOnPrimaryContainer,
                    ),
                    CustomElevatedButton(
                      height: 38.v,
                      width: 89.h,
                      text: "05:00 PM",
                      margin: EdgeInsets.only(left: 12.h),
                      leftIcon: Container(
                        margin: EdgeInsets.only(right: 5.h),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgClock,
                          height: 18.adaptSize,
                          width: 18.adaptSize,
                        ),
                      ),
                      buttonStyle: CustomButtonStyles.fillBlack,
                      buttonTextStyle:
                          CustomTextStyles.labelMediumOnPrimaryContainer,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildDoctorSpecialityGrid(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20.h),
      child: Column(
        children: [
          _buildFrame(
            context,
            doctorSpeciality: "Doctor Speciality ",
            seeAllPrice: "SEE ALL",
          ),
          SizedBox(height: 19.v),
          GridView.builder(
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              mainAxisExtent: 83.v,
              crossAxisCount: 4,
              mainAxisSpacing: 31.h,
              crossAxisSpacing: 31.h,
            ),
            physics: NeverScrollableScrollPhysics(),
            itemCount: 10,
            itemBuilder: (context, index) {
              return GeneralcomponentItemWidget();
            },
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildListTabStack(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: IntrinsicWidth(
        child: SizedBox(
          height: 36.v,
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.centerLeft,
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  height: 36.v,
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  margin: EdgeInsets.only(left: 20.h),
                  padding: EdgeInsets.symmetric(
                    horizontal: 29.h,
                    vertical: 5.v,
                  ),
                  decoration: AppDecoration.gradientIndigoAToPrimary.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder20,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(height: 3.v),
                      Text(
                        "Open",
                        style: CustomTextStyles.titleSmallOnPrimaryContainer,
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 128.h),
                  child: OutlineGradientButton(
                    padding: EdgeInsets.only(
                      left: 1.h,
                      top: 1.v,
                      right: 1.h,
                      bottom: 1.v,
                    ),
                    strokeWidth: 1.h,
                    gradient: LinearGradient(
                      begin: Alignment(1, 1),
                      end: Alignment(-0.24, -0.31),
                      colors: [
                        appTheme.indigoA100,
                        theme.colorScheme.primary,
                      ],
                    ),
                    corners: Corners(
                      topLeft: Radius.circular(18),
                      topRight: Radius.circular(18),
                      bottomLeft: Radius.circular(18),
                      bottomRight: Radius.circular(18),
                    ),
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 19.h,
                        vertical: 6.v,
                      ),
                      decoration: AppDecoration.outline.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder20,
                      ),
                      child: Text(
                        "General",
                        style: CustomTextStyles.bodyMediumIndigoA100,
                      ),
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 41.h),
                  child: OutlineGradientButton(
                    padding: EdgeInsets.only(
                      left: 1.h,
                      top: 1.v,
                      right: 1.h,
                      bottom: 1.v,
                    ),
                    strokeWidth: 1.h,
                    gradient: LinearGradient(
                      begin: Alignment(1, 1),
                      end: Alignment(-0.24, -0.31),
                      colors: [
                        appTheme.indigoA100,
                        theme.colorScheme.primary,
                      ],
                    ),
                    corners: Corners(
                      topLeft: Radius.circular(18),
                      topRight: Radius.circular(18),
                      bottomLeft: Radius.circular(18),
                      bottomRight: Radius.circular(18),
                    ),
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 23.h,
                        vertical: 6.v,
                      ),
                      decoration: AppDecoration.outline.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder20,
                      ),
                      child: Text(
                        "Dentist",
                        style: CustomTextStyles.bodyMediumIndigoA100,
                      ),
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: OutlineGradientButton(
                  padding: EdgeInsets.only(
                    left: 1.h,
                    top: 1.v,
                    right: 1.h,
                    bottom: 1.v,
                  ),
                  strokeWidth: 1.h,
                  gradient: LinearGradient(
                    begin: Alignment(1, 1),
                    end: Alignment(-0.24, -0.31),
                    colors: [
                      appTheme.indigoA100,
                      theme.colorScheme.primary,
                    ],
                  ),
                  corners: Corners(
                    topLeft: Radius.circular(18),
                    topRight: Radius.circular(18),
                    bottomLeft: Radius.circular(18),
                    bottomRight: Radius.circular(18),
                  ),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 26.h,
                      vertical: 6.v,
                    ),
                    decoration: AppDecoration.outline.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder20,
                    ),
                    child: Text(
                      "Partial",
                      textAlign: TextAlign.center,
                      style: CustomTextStyles.bodyMediumIndigoA100,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildFrame(
    BuildContext context, {
    required String doctorSpeciality,
    required String seeAllPrice,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          doctorSpeciality,
          style: theme.textTheme.titleMedium!.copyWith(
            color: appTheme.gray90001,
          ),
        ),
        Padding(
          padding: EdgeInsets.only(bottom: 4.v),
          child: Text(
            seeAllPrice,
            style: CustomTextStyles.labelLargeIndigoA100.copyWith(
              color: appTheme.indigoA100,
            ),
          ),
        ),
      ],
    );
  }
}
