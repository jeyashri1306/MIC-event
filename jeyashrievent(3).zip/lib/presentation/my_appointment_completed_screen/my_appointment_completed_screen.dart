import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/forget_password_page/forget_password_page.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_bottom_bar.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_elevated_button.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_icon_button.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_switch.dart';

// ignore_for_file: must_be_immutable
class MyAppointmentCompletedScreen extends StatelessWidget {
  MyAppointmentCompletedScreen({Key? key}) : super(key: key);

  bool isSelectedSwitch = false;

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 20.h, vertical: 19.v),
                child: Column(children: [
                  SizedBox(height: 9.v),
                  _buildProfileSection(context),
                  SizedBox(height: 24.v),
                  _buildSettingsSection(context),
                  SizedBox(height: 24.v),
                  _buildNotificationSection(context),
                  SizedBox(height: 24.v),
                  _buildOthersSection(context)
                ])),
            bottomNavigationBar: _buildBottomBar(context)));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        height: 44.v,
        title: AppbarTitle(
            text: "My Profile", margin: EdgeInsets.only(left: 20.h)),
        actions: [
          AppbarTrailingIconbutton(
              imagePath: ImageConstant.imgSettings,
              margin: EdgeInsets.symmetric(horizontal: 20.h, vertical: 10.v))
        ],
        styleType: Style.bgFill_1);
  }

  /// Section Widget
  Widget _buildProfileSection(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      CustomIconButton(
          height: 55.adaptSize,
          width: 55.adaptSize,
          onTap: () {
            onTapBtnClose(context);
          },
          child: CustomImageView(imagePath: ImageConstant.imgClose)),
      Padding(
          padding: EdgeInsets.only(left: 15.h, top: 7.v, bottom: 5.v),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text("Stefani Wong",
                style: CustomTextStyles.titleMediumSourceSansProOnPrimary),
            SizedBox(height: 4.v),
            RichText(
                text: TextSpan(children: [
                  TextSpan(
                      text: "Joined since",
                      style:
                          CustomTextStyles.bodyMediumSourceSansProBluegray400),
                  TextSpan(text: " "),
                  TextSpan(
                      text: "27 Dec 2020 ",
                      style: CustomTextStyles
                          .bodyMediumSourceSansProOnSecondaryContainer)
                ]),
                textAlign: TextAlign.left)
          ])),
      Spacer(),
      CustomElevatedButton(
          height: 30.v,
          width: 83.h,
          text: "Edit",
          margin: EdgeInsets.only(top: 10.v, bottom: 15.v),
          buttonStyle: CustomButtonStyles.none,
          decoration: CustomButtonStyles.gradientIndigoAToPrimaryTL15Decoration,
          buttonTextStyle: CustomTextStyles.labelLargeMedium)
    ]);
  }

  /// Section Widget
  Widget _buildSettingsSection(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 20.h, vertical: 22.v),
        decoration: AppDecoration.outlineGray
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder15),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Align(
              alignment: Alignment.centerLeft,
              child: Text("Settings",
                  style: CustomTextStyles.titleMediumSourceSansProOnPrimary)),
          SizedBox(height: 20.v),
          _buildAboutSection(context,
              aboutImage: ImageConstant.imgFrame1171275207,
              aboutText: "Languages"),
          SizedBox(height: 19.v),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            CustomImageView(
                imagePath: ImageConstant.imgFrame20x20,
                height: 20.adaptSize,
                width: 20.adaptSize),
            Padding(
                padding: EdgeInsets.only(left: 10.h),
                child: Text("Location",
                    style: CustomTextStyles.bodySmallBluegray400)),
            Spacer(),
            CustomImageView(
                imagePath: ImageConstant.imgArrowRight,
                height: 18.adaptSize,
                width: 18.adaptSize)
          ])
        ]));
  }

  /// Section Widget
  Widget _buildNotificationSection(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(20.h),
        decoration: AppDecoration.outlineGray
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder15),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Notification",
                  style: CustomTextStyles.titleMediumSourceSansProOnPrimary),
              SizedBox(height: 19.v),
              Row(children: [
                CustomImageView(
                    imagePath: ImageConstant.imgNotificationIcon,
                    height: 20.adaptSize,
                    width: 20.adaptSize),
                Padding(
                    padding: EdgeInsets.only(left: 10.h),
                    child: Text("Pop-up Notification",
                        style: CustomTextStyles.bodySmallBluegray400)),
                Spacer(),
                CustomSwitch(
                    value: isSelectedSwitch,
                    onChange: (value) {
                      isSelectedSwitch = value;
                    })
              ])
            ]));
  }

  /// Section Widget
  Widget _buildOthersSection(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 20.h, vertical: 9.v),
        decoration: AppDecoration.outlineGray
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder15),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              SizedBox(height: 11.v),
              Align(
                  alignment: Alignment.centerLeft,
                  child: Text("Others",
                      style:
                          CustomTextStyles.titleMediumSourceSansProOnPrimary)),
              SizedBox(height: 20.v),
              _buildAboutSection(context,
                  aboutImage: ImageConstant.imgAbout, aboutText: "About Us"),
              SizedBox(height: 20.v),
              _buildAboutSection(context,
                  aboutImage: ImageConstant.imgCustomerService,
                  aboutText: "Customer Service"),
              SizedBox(height: 20.v),
              _buildAboutSection(context,
                  aboutImage: ImageConstant.imgInviteTeam,
                  aboutText: "Invite Other"),
              SizedBox(height: 20.v),
              Align(
                  alignment: Alignment.centerLeft,
                  child: Row(children: [
                    CustomImageView(
                        imagePath: ImageConstant.imgThumbsUp,
                        height: 20.adaptSize,
                        width: 20.adaptSize),
                    Padding(
                        padding: EdgeInsets.only(left: 10.h, top: 2.v),
                        child: Text("Logout",
                            style: CustomTextStyles.bodySmallBluegray400))
                  ]))
            ]));
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));
    });
  }

  /// Common widget
  Widget _buildAboutSection(
    BuildContext context, {
    required String aboutImage,
    required String aboutText,
  }) {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      CustomImageView(
          imagePath: aboutImage, height: 20.adaptSize, width: 20.adaptSize),
      Padding(
          padding: EdgeInsets.only(left: 10.h),
          child: Text(aboutText,
              style: CustomTextStyles.bodySmallBluegray400
                  .copyWith(color: appTheme.blueGray400))),
      Spacer(),
      CustomImageView(
          imagePath: ImageConstant.imgArrowRight,
          height: 18.adaptSize,
          width: 18.adaptSize)
    ]);
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.forgetPasswordPage;
      case BottomBarEnum.Appointment:
        return "/";
      case BottomBarEnum.Doctors:
        return "/";
      case BottomBarEnum.Article:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.forgetPasswordPage:
        return ForgetPasswordPage();
      default:
        return DefaultWidget();
    }
  }

  /// Navigates back to the previous screen.
  onTapBtnClose(BuildContext context) {
    Navigator.pop(context);
  }
}
