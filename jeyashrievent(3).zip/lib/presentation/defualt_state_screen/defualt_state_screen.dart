import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_leading_image.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_subtitle_two.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_elevated_button.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class DefualtStateScreen extends StatelessWidget {
  DefualtStateScreen({Key? key}) : super(key: key);

  TextEditingController userNameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  TextEditingController confirmpasswordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: Column(children: [
                      _buildFrame(context),
                      SizedBox(height: 48.v),
                      _buildUserName(context),
                      SizedBox(height: 16.v),
                      _buildEmail(context),
                      SizedBox(height: 16.v),
                      _buildPassword(context),
                      SizedBox(height: 16.v),
                      _buildConfirmpassword(context),
                      SizedBox(height: 32.v),
                      _buildCREATEACCOUNT(context),
                      SizedBox(height: 25.v),
                      _buildFrame1(context),
                      SizedBox(height: 19.v),
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 40.h),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                    height: 52.v,
                                    width: 77.h,
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 24.h, vertical: 12.v),
                                    decoration: AppDecoration.outlineIndigo
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder15),
                                    child: CustomImageView(
                                        imagePath: ImageConstant.imgFrame,
                                        height: 26.adaptSize,
                                        width: 26.adaptSize,
                                        alignment: Alignment.center)),
                                Spacer(flex: 50),
                                Container(
                                    height: 52.v,
                                    width: 77.h,
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 24.h, vertical: 12.v),
                                    decoration: AppDecoration.outlineIndigo
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder15),
                                    child: CustomImageView(
                                        imagePath:
                                            ImageConstant.imgFrameDeepOrange500,
                                        height: 26.adaptSize,
                                        width: 26.adaptSize,
                                        alignment: Alignment.center)),
                                Spacer(flex: 50),
                                Container(
                                    height: 52.v,
                                    width: 77.h,
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 24.h, vertical: 12.v),
                                    decoration: AppDecoration.outlineIndigo
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder15),
                                    child: CustomImageView(
                                        imagePath:
                                            ImageConstant.imgFrameBlack900,
                                        height: 26.adaptSize,
                                        width: 26.adaptSize,
                                        alignment: Alignment.center))
                              ])),
                      SizedBox(height: 5.v)
                    ])))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 40.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 16.h, top: 14.v, bottom: 14.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        actions: [
          AppbarSubtitleTwo(
              text: "Sign In",
              margin: EdgeInsets.fromLTRB(16.h, 13.v, 16.h, 17.v))
        ],
        styleType: Style.bgFill);
  }

  /// Section Widget
  Widget _buildFrame(BuildContext context) {
    return Container(
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 14.v),
        decoration: AppDecoration.fillOnPrimaryContainer,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 3.v),
              SizedBox(
                  width: 209.h,
                  child: Text("Create Your  Account",
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style:
                          theme.textTheme.displaySmall!.copyWith(height: 1.41)))
            ]));
  }

  /// Section Widget
  Widget _buildUserName(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        child: CustomTextFormField(
            controller: userNameController, hintText: "User Name"));
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        child: CustomTextFormField(
            controller: emailController,
            hintText: "Email",
            textInputType: TextInputType.emailAddress));
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        child: CustomTextFormField(
            controller: passwordController,
            hintText: "Password",
            textInputType: TextInputType.visiblePassword,
            suffix: Container(
                margin: EdgeInsets.fromLTRB(30.h, 16.v, 16.h, 16.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgEye,
                    height: 24.adaptSize,
                    width: 24.adaptSize)),
            suffixConstraints: BoxConstraints(maxHeight: 56.v),
            obscureText: true,
            contentPadding:
                EdgeInsets.only(left: 16.h, top: 19.v, bottom: 19.v)));
  }

  /// Section Widget
  Widget _buildConfirmpassword(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        child: CustomTextFormField(
            controller: confirmpasswordController,
            hintText: "Confirm Password",
            textInputAction: TextInputAction.done,
            textInputType: TextInputType.visiblePassword,
            suffix: Container(
                margin: EdgeInsets.fromLTRB(30.h, 16.v, 16.h, 16.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgEye,
                    height: 24.adaptSize,
                    width: 24.adaptSize)),
            suffixConstraints: BoxConstraints(maxHeight: 56.v),
            obscureText: true,
            contentPadding:
                EdgeInsets.only(left: 16.h, top: 19.v, bottom: 19.v)));
  }

  /// Section Widget
  Widget _buildCREATEACCOUNT(BuildContext context) {
    return Opacity(
        opacity: 0.4,
        child: CustomElevatedButton(
            text: "CREATE ACCOUNT",
            margin: EdgeInsets.symmetric(horizontal: 16.h),
            buttonStyle: CustomButtonStyles.none,
            decoration: CustomButtonStyles.gradientIndigoAToOnErrorDecoration));
  }

  /// Section Widget
  Widget _buildFrame1(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 15.h),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Padding(
                  padding: EdgeInsets.only(top: 10.v, bottom: 9.v),
                  child: SizedBox(width: 108.h, child: Divider())),
              Padding(
                  padding: EdgeInsets.only(left: 14.h),
                  child: Text("or create with",
                      style: CustomTextStyles.bodyMediumErrorContainer)),
              Padding(
                  padding: EdgeInsets.only(top: 10.v, bottom: 9.v),
                  child: SizedBox(width: 123.h, child: Divider(indent: 15.h)))
            ]));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }
}
