import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_elevated_button.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_outlined_button.dart';

class LoginAsScreen extends StatelessWidget {
  const LoginAsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(1, 1),
              end: Alignment(-0.24, -0.31),
              colors: [
                appTheme.indigoA100,
                theme.colorScheme.primary,
              ],
            ),
          ),
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(
              horizontal: 12.h,
              vertical: 51.v,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Spacer(
                  flex: 43,
                ),
                CustomImageView(
                  imagePath: ImageConstant.imgFrame1171275125,
                  height: 96.adaptSize,
                  width: 96.adaptSize,
                ),
                Spacer(
                  flex: 56,
                ),
                SizedBox(
                  width: 349.h,
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "By tapping ‘Sign in’ you agree to our ",
                          style: CustomTextStyles.bodySmallOnPrimaryContainer12,
                        ),
                        TextSpan(
                          text: "Terms",
                          style: theme.textTheme.labelLarge!.copyWith(
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        TextSpan(
                          text: ".\nLearn how we process your data in our ",
                          style: CustomTextStyles.bodySmallOnPrimaryContainer12
                              .copyWith(
                            height: 1.33,
                          ),
                        ),
                        TextSpan(
                          text: "Privacy Policy",
                          style: theme.textTheme.labelLarge!.copyWith(
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        TextSpan(
                          text: " and\n",
                          style: CustomTextStyles.bodySmallOnPrimaryContainer12,
                        ),
                        TextSpan(
                          text: "Cookies Policy.",
                          style: theme.textTheme.labelLarge!.copyWith(
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(height: 21.v),
                CustomElevatedButton(
                  text: "CREATE ACCOUNT",
                  margin: EdgeInsets.symmetric(horizontal: 4.h),
                  buttonStyle: CustomButtonStyles.fillOnPrimaryContainer,
                  buttonTextStyle: CustomTextStyles.titleMediumIndigoA100,
                ),
                SizedBox(height: 16.v),
                CustomOutlinedButton(
                  height: 52.v,
                  text: "SIGN IN",
                  margin: EdgeInsets.symmetric(horizontal: 4.h),
                  buttonStyle: CustomButtonStyles.outlineOnPrimaryContainer,
                  buttonTextStyle:
                      CustomTextStyles.titleMediumOnPrimaryContainer,
                ),
                SizedBox(height: 24.v),
                Text(
                  "Trouble signing in?",
                  style: CustomTextStyles.bodySmallOnPrimaryContainer,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
