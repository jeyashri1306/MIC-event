import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_leading_image.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/appbar_subtitle.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_elevated_button.dart';
import 'package:thameeml_ansari_u_s_application1/widgets/custom_pin_code_text_field.dart';

class ForgetPasswordOneScreen extends StatelessWidget {
  const ForgetPasswordOneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.only(left: 16.h, top: 80.v, right: 16.h),
                child: Column(children: [
                  SizedBox(
                      width: 182.h,
                      child: Text("Code has been sent to \nexample@gmail.com",
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodyLarge!
                              .copyWith(height: 1.38))),
                  SizedBox(height: 29.v),
                  Padding(
                      padding: EdgeInsets.symmetric(horizontal: 2.h),
                      child: CustomPinCodeTextField(
                          context: context, onChanged: (value) {})),
                  SizedBox(height: 33.v),
                  RichText(
                      text: TextSpan(children: [
                        TextSpan(
                            text: "Didn’t received code? ",
                            style: theme.textTheme.bodyMedium),
                        TextSpan(
                            text: "Resend",
                            style: CustomTextStyles.bodyMediumDeeppurpleA100)
                      ]),
                      textAlign: TextAlign.left),
                  SizedBox(height: 33.v),
                  CustomElevatedButton(
                      text: "VERIFY",
                      buttonStyle: CustomButtonStyles.none,
                      decoration: CustomButtonStyles
                          .gradientIndigoAToPrimaryDecoration),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 40.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 16.h, top: 14.v, bottom: 14.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarSubtitle(text: "Forget Password"),
        styleType: Style.bgFill_1);
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }
}
