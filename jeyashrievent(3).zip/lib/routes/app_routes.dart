import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/login_as_screen/login_as_screen.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/defualt_state_screen/defualt_state_screen.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/forget_password_one_screen/forget_password_one_screen.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/forget_password_container_screen/forget_password_container_screen.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/doctors_tab_container_screen/doctors_tab_container_screen.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/my_appointment_completed_screen/my_appointment_completed_screen.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/book_appointment_active_screen/book_appointment_active_screen.dart';
import 'package:thameeml_ansari_u_s_application1/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String loginAsScreen = '/login_as_screen';

  static const String defualtStateScreen = '/defualt_state_screen';

  static const String forgetPasswordOneScreen = '/forget_password_one_screen';

  static const String forgetPasswordPage = '/forget_password_page';

  static const String forgetPasswordContainerScreen =
      '/forget_password_container_screen';

  static const String doctorsPage = '/doctors_page';

  static const String doctorsTabContainerScreen =
      '/doctors_tab_container_screen';

  static const String myAppointmentCompletedScreen =
      '/my_appointment_completed_screen';

  static const String bookAppointmentActiveScreen =
      '/book_appointment_active_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    loginAsScreen: (context) => LoginAsScreen(),
    defualtStateScreen: (context) => DefualtStateScreen(),
    forgetPasswordOneScreen: (context) => ForgetPasswordOneScreen(),
    forgetPasswordContainerScreen: (context) => ForgetPasswordContainerScreen(),
    doctorsTabContainerScreen: (context) => DoctorsTabContainerScreen(),
    myAppointmentCompletedScreen: (context) => MyAppointmentCompletedScreen(),
    bookAppointmentActiveScreen: (context) => BookAppointmentActiveScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
