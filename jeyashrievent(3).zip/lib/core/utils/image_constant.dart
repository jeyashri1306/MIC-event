class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Login As images
  static String imgFrame1171275125 = '$imagePath/img_frame_1171275125.png';

  // Defualt State images
  static String imgEye = '$imagePath/img_eye.svg';

  static String imgFrame = '$imagePath/img_frame.svg';

  static String imgFrameDeepOrange500 =
      '$imagePath/img_frame_deep_orange_500.svg';

  static String imgFrameBlack900 = '$imagePath/img_frame_black_900.svg';

  // Doctors images
  static String imgImage6 = '$imagePath/img_image_6.png';

  static String imgComponent1 = '$imagePath/img_component_1.png';

  static String imgImage9 = '$imagePath/img_image_9.png';

  static String imgClockOnprimarycontainer =
      '$imagePath/img_clock_onprimarycontainer.svg';

  static String imgImage7 = '$imagePath/img_image_7.png';

  static String imgImage874x67 = '$imagePath/img_image_8_74x67.png';

  static String imgStar1 = '$imagePath/img_star_1.svg';

  static String imgStar2 = '$imagePath/img_star_2.svg';

  static String imgStar3 = '$imagePath/img_star_3.svg';

  static String imgStar4 = '$imagePath/img_star_4.svg';

  static String imgStar5 = '$imagePath/img_star_5.svg';

  static String imgStar6 = '$imagePath/img_star_6.svg';

  // Doctors - Tab Container images
  static String imgRewindPrimarycontainer =
      '$imagePath/img_rewind_primarycontainer.svg';

  static String imgShare = '$imagePath/img_share.svg';

  static String imgNavDoctors24x24 = '$imagePath/img_nav_doctors_24x24.png';

  // My Appointment-Completed images
  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgClose = '$imagePath/img_close.svg';

  static String imgFrame1171275207 = '$imagePath/img_frame_1171275207.png';

  static String imgArrowRight = '$imagePath/img_arrow_right.svg';

  static String imgFrame20x20 = '$imagePath/img_frame_20x20.png';

  static String imgNotificationIcon = '$imagePath/img_notification_icon.png';

  static String imgAbout = '$imagePath/img_about.png';

  static String imgCustomerService = '$imagePath/img_customer_service.png';

  static String imgInviteTeam = '$imagePath/img_invite_team.png';

  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgNavProfile24x24 = '$imagePath/img_nav_profile_24x24.png';

  // Book Appointment -Active images
  static String imgImage81 = '$imagePath/img_image_8_1.png';

  static String imgIconLocation = '$imagePath/img_icon_location.png';

  // Common images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgPlay = '$imagePath/img_play.svg';

  static String imgFrame1171275198 = '$imagePath/img_frame_1171275198.svg';

  static String imgFramePrimarycontainer =
      '$imagePath/img_frame_primarycontainer.svg';

  static String imgRewind = '$imagePath/img_rewind.svg';

  static String imgIconlyLightFilter = '$imagePath/img_iconly_light_filter.png';

  static String imgBanner = '$imagePath/img_banner.svg';

  static String imgImage8 = '$imagePath/img_image_8.png';

  static String imgNotification = '$imagePath/img_notification.svg';

  static String imgCalendar = '$imagePath/img_calendar.svg';

  static String imgClock = '$imagePath/img_clock.svg';

  static String imgGeneral = '$imagePath/img_general.png';

  static String imgDentist = '$imagePath/img_dentist.png';

  static String imgOtology = '$imagePath/img_otology.png';

  static String imgOphthalmology = '$imagePath/img_ophthalmology.png';

  static String imgIntestine = '$imagePath/img_intestine.png';

  static String imgPediatric = '$imagePath/img_pediatric.png';

  static String imgHerbal = '$imagePath/img_herbal.png';

  static String imgMore = '$imagePath/img_more.png';

  static String imgNavHome24x24 = '$imagePath/img_nav_home_24x24.png';

  static String imgNavAppointment = '$imagePath/img_nav_appointment.svg';

  static String imgNavDoctors = '$imagePath/img_nav_doctors.svg';

  static String imgNavArticle = '$imagePath/img_nav_article.svg';

  static String imgNavProfile = '$imagePath/img_nav_profile.svg';

  static String imgNavHome = '$imagePath/img_nav_home.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
